To start the retirement finances program, enter 'retirement_finances
in a new terminal window after running install.sh.
