#!/bin/bash

# Remove the files created during installation
python3 -m pipx uninstall retirement_finances


